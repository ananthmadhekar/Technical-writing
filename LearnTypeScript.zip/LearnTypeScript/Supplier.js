"use strict";
var Supplier = (function () {
    function Supplier() {
        this._name = "";
        this.location = "";
    }
    Object.defineProperty(Supplier.prototype, "name", {
        get: function () {
            return this._name;
        },
        set: function (value) {
            this._name = value;
        },
        enumerable: true,
        configurable: true
    });
    return Supplier;
}());
exports.Supplier = Supplier;
//# sourceMappingURL=Supplier.js.map