﻿export class Supplier {
    public _name: string = "";

    public set name(value: string) {
        this._name = value;
    }

    public get name() {
        return this._name;
    }

    public location: string = "";

}