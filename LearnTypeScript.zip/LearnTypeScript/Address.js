"use strict";
var Address = (function () {
    function Address() {
        this.street = "";
        this.landMark = "";
        this.houseNo = 0;
        this.SSN = 0;
    }
    return Address;
}());
exports.Address = Address;
//# sourceMappingURL=Address.js.map