"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
//@ts-check
var Supplier_1 = require('./Supplier');
var Address_1 = require('./Address');
var Customer = (function (_super) {
    __extends(Customer, _super);
    function Customer() {
        _super.apply(this, arguments);
        this._customerName = "";
        this._customerCode = "";
        this.supplierObj = new Supplier_1.Supplier();
        this.addressObj = new Address_1.Address();
    }
    Customer.prototype.add = function (a, b) {
        return a + b;
    };
    return Customer;
}(Address_1.Address));
exports.Customer = Customer;
//# sourceMappingURL=Customer.js.map