﻿//@ts-check
import {Supplier} from './Supplier'
import {Address} from './Address'


interface iCustomer {
    add(number1:number, number2:number);
}

export class Customer extends Address implements iCustomer {
    public _customerName: string = "";
    public _customerCode: string = "";

    public supplierObj: Supplier = new Supplier();
    public addressObj: Address = new Address();

    add(a: number, b: number) {               
        return a + b;
    }
}