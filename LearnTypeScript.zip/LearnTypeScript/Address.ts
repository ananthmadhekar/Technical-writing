﻿export class Address {
    public street: string = "";
    public landMark: string = "";
    protected houseNo: number = 0;
    private SSN: number = 0;
}